import os
from functools import wraps
from datetime import datetime
from ipaddress import ip_network, ip_address
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
# Absolute SQLite path for Apache/mod_wsgi
basedir = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", f"sqlite:///{os.path.join(basedir,'ipam.db')}")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-in-production")

db = SQLAlchemy(app)
auth = HTTPBasicAuth()

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)
    def set_password(self, pwd): self.password_hash = generate_password_hash(pwd)
    def check_password(self, pwd): return check_password_hash(self.password_hash, pwd)

class Subnet(db.Model):
    __tablename__ = "subnets"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    cidr = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    ip_addresses = db.relationship("IPAddress", backref="subnet", cascade="all, delete-orphan")
    def network(self): return ip_network(self.cidr, strict=False)
    def total_hosts(self): return sum(1 for _ in self.network().hosts())
    def used_count(self): return IPAddress.query.filter_by(subnet_id=self.id).count()
    def free_count(self): return self.total_hosts() - self.used_count()

class IPAddress(db.Model):
    __tablename__ = "ip_addresses"
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(64), nullable=False)
    hostname = db.Column(db.String(255), default="")
    status = db.Column(db.String(32), default="assigned")
    assigned_to = db.Column(db.String(255), default="")
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    subnet_id = db.Column(db.Integer, db.ForeignKey("subnets.id"), nullable=False)
    __table_args__ = (db.UniqueConstraint("subnet_id","ip",name="uq_subnet_ip"),)

class IPRequest(db.Model):
    __tablename__ = "ip_requests"
    id = db.Column(db.Integer, primary_key=True)
    subnet_id = db.Column(db.Integer, db.ForeignKey("subnets.id"), nullable=False)
    ip = db.Column(db.String(64), nullable=True)
    mode = db.Column(db.String(16), default="next_free")
    hostname = db.Column(db.String(255), default="")
    assigned_to = db.Column(db.String(255), default="")
    notes = db.Column(db.Text, default="")
    status = db.Column(db.String(16), default="pending")
    admin_comment = db.Column(db.Text, default="")
    requested_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    requested_by = db.relationship("User")
    subnet = db.relationship("Subnet")

@auth.verify_password
def verify_password(username, password):
    u = User.query.filter_by(username=username).first()
    return u if u and u.check_password(password) else None

def admin_required(f):
    from functools import wraps
    @wraps(f)
    @auth.login_required
    def wrapped(*args, **kwargs):
        user = auth.current_user()
        if not user or not user.is_admin: abort(403)
        return f(*args, **kwargs)
    return wrapped

@app.errorhandler(403)
def forbidden(e):
    flash("You do not have permission to perform that action.", "warning")
    return redirect(url_for("dashboard"))

@app.context_processor
def inject_current_user():
    return {"current_user": auth.current_user()}

# Helpers

def find_next_free_ip(subnet):
    net = subnet.network()
    used = {ip_address(rec.ip) for rec in IPAddress.query.filter_by(subnet_id=subnet.id)}
    for host in net.hosts():
        if host not in used:
            return host
    return None

def validate_ip_in_subnet(ip_str, subnet):
    try:
        ip_obj = ip_address(ip_str)
    except ValueError:
        return False, "Invalid IP format"
    if ip_obj not in subnet.network():
        return False, f"{ip_str} is not inside {subnet.cidr}"
    net = subnet.network()
    if net.version == 4 and net.prefixlen < 31 and ip_obj in (net.network_address, net.broadcast_address):
        return False, f"{ip_str} is network/broadcast for {subnet.cidr}"
    return True, ""

# Startup DB init for Flask 3/mod_wsgi

def init_db():
    db.create_all()
    if User.query.count() == 0:
        u = User(username=os.environ.get("IPAM_ADMIN_USER","admin"), is_admin=True)
        u.set_password(os.environ.get("IPAM_ADMIN_PASS","admin"))
        db.session.add(u); db.session.commit()

with app.app_context():
    init_db()

# Routes (only key ones to keep file short)
@app.route("/")
@auth.login_required
def dashboard():
    subnets = Subnet.query.order_by(Subnet.created_at.desc()).all()
    totals = {
        "subnets": len(subnets),
        "total_hosts": sum(s.total_hosts() for s in subnets) if subnets else 0,
        "used": sum(s.used_count() for s in subnets) if subnets else 0,
        "free": sum(s.free_count() for s in subnets) if subnets else 0,
    }
    user = auth.current_user()
    from sqlalchemy import func
    def count(status):
        from . import IPRequest  # noqa
        return IPRequest.query.filter_by(status=status).count() if user.is_admin else IPRequest.query.filter_by(status=status, requested_by_id=user.id).count()
    req_counts = {"pending": count("pending"), "approved": count("approved"), "rejected": count("rejected")}
    return render_template("dashboard.html", subnets=subnets, totals=totals, req_counts=req_counts)

@app.route("/subnets")
@auth.login_required
def list_subnets():
    subnets = Subnet.query.order_by(Subnet.cidr.asc()).all()
    return render_template("subnets.html", subnets=subnets)

@app.route("/subnets/new", methods=["GET","POST"])
@admin_required
def new_subnet():
    if request.method == "POST":
        name = request.form.get("name","" ).strip()
        cidr = request.form.get("cidr","" ).strip()
        description = request.form.get("description","" ).strip()
        try:
            net = ip_network(cidr, strict=False)
        except Exception as e:
            flash(f"Invalid network: {e}", "danger"); return render_template("subnet_form.html")
        if Subnet.query.filter_by(cidr=str(net)).first():
            flash("This subnet already exists.", "warning"); return render_template("subnet_form.html")
        s = Subnet(name=name or str(net), cidr=str(net), description=description)
        db.session.add(s); db.session.commit()
        flash("Subnet created.", "success"); return redirect(url_for("list_subnets"))
    return render_template("subnet_form.html")

@app.route("/subnets/<int:subnet_id>")
@auth.login_required
def subnet_detail(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    allocations = IPAddress.query.filter_by(subnet_id=subnet.id).order_by(IPAddress.ip.asc()).all()
    reserved = sum(1 for a in allocations if a.status == "reserved")
    assigned = sum(1 for a in allocations if a.status == "assigned")
    return render_template("subnet_detail.html", subnet=subnet, allocations=allocations, reserved=reserved, assigned=assigned)

@app.route("/subnets/<int:subnet_id>/assign", methods=["GET","POST"])
@admin_required
def assign_ip(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    if request.method == "POST":
        mode = request.form.get("mode","next_free")
        hostname = request.form.get("hostname","" ).strip()
        assigned_to = request.form.get("assigned_to","" ).strip()
        status = request.form.get("status","assigned")
        notes = request.form.get("notes","" ).strip()
        if mode == "next_free":
            chosen = find_next_free_ip(subnet)
            if not chosen:
                flash("No free IPs left in this subnet.", "warning"); return render_template("ip_assign_form.html", subnet=subnet)
        else:
            ip_str = request.form.get("ip","" ).strip()
            ok, msg = validate_ip_in_subnet(ip_str, subnet)
            if not ok:
                flash(msg, "danger"); return render_template("ip_assign_form.html", subnet=subnet)
            chosen = ip_address(ip_str)
            if IPAddress.query.filter_by(subnet_id=subnet.id, ip=str(chosen)).first():
                flash("That IP is already allocated.", "danger"); return render_template("ip_assign_form.html", subnet=subnet)
        rec = IPAddress(ip=str(chosen), hostname=hostname, assigned_to=assigned_to, status=status, notes=notes, subnet_id=subnet.id)
        db.session.add(rec); db.session.commit(); flash(f"Allocated {chosen}", "success")
        return redirect(url_for("subnet_detail", subnet_id=subnet.id))
    return render_template("ip_assign_form.html", subnet=subnet)

@app.route("/ips/<int:ip_id>/release", methods=["POST"])
@admin_required
def release_ip(ip_id):
    rec = IPAddress.query.get_or_404(ip_id)
    sid = rec.subnet_id
    db.session.delete(rec); db.session.commit(); flash("IP released.", "info")
    return redirect(url_for("subnet_detail", subnet_id=sid))

@app.route("/admin/users")
@admin_required
def admin_users():
    users = User.query.order_by(User.username.asc()).all()
    return render_template("admin_users.html", users=users)

@app.route("/admin/users/new", methods=["GET","POST"])
@admin_required
def admin_users_new():
    if request.method == "POST":
        username = request.form.get("username","" ).strip()
        password = request.form.get("password","" ).strip()
        is_admin = request.form.get("is_admin") == "on"
        if not username or not password:
            flash("Username and password are required.", "danger"); return render_template("admin_user_form.html")
        if User.query.filter_by(username=username).first():
            flash("User already exists.", "warning"); return render_template("admin_user_form.html")
        u = User(username=username, is_admin=is_admin); u.set_password(password)
        db.session.add(u); db.session.commit(); flash("User created.", "success")
        return redirect(url_for("admin_users"))
    return render_template("admin_user_form.html")

@app.route("/integrations/alta/webhook", methods=["POST"])
@admin_required
def alta_webhook():
    data = request.get_json(silent=True) or {}
    events = data.get("events", [])
    created = 0
    for ev in events:
        ip_str = ev.get("ip"); hostname = ev.get("hostname","" ); assigned_to = ev.get("mac","" )
        if not ip_str: continue
        for s in Subnet.query.all():
            ok, msg = validate_ip_in_subnet(ip_str, s)
            if ok:
                if not IPAddress.query.filter_by(subnet_id=s.id, ip=ip_str).first():
                    rec = IPAddress(ip=ip_str, hostname=hostname, assigned_to=assigned_to, status="assigned", notes="Alta webhook", subnet_id=s.id)
                    db.session.add(rec); created += 1
                break
    if created: db.session.commit()
    return {"created": created}, 201
