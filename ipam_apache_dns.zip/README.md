# IPAM (Flask) for Apache/mod_wsgi with Alta Route10 Collector (DNS)

This package contains:
- `app.py` — Flask app with RBAC, request workflow, admin user UI
- `ipam.wsgi` — WSGI entrypoint for Apache `mod_wsgi`
- `alta_route10_collector.py` — ARP-based DHCP discovery with reverse DNS (PTR) lookups
- `templates/` — Web UI
- `systemd/*.service|*.timer` — schedule the collector every minute
- `apache/ipam.conf` — example VirtualHost

## Deploy on Ubuntu/Debian (Apache/mod_wsgi)
```bash
sudo apt-get update
sudo apt-get install -y apache2 libapache2-mod-wsgi-py3 python3-venv
sudo mkdir -p /var/www/ipam && sudo chown -R $USER:$USER /var/www/ipam
# copy all files here to /var/www/ipam
python3 -m venv /var/www/ipam/.venv
source /var/www/ipam/.venv/bin/activate
pip install -r /var/www/ipam/requirements.txt
```

Create site config and enable:
```bash
sudo mkdir -p /etc/apache2/sites-available
sudo cp /var/www/ipam/apache/ipam.conf /etc/apache2/sites-available/
sudo a2enmod wsgi
sudo a2ensite ipam.conf
sudo systemctl reload apache2
```

DB init happens at import via `with app.app_context(): init_db()`.

## Collector (Alta Route10 → IPAM via ARP + DNS)
Install systemd units and enable timer:
```bash
sudo cp /var/www/ipam/systemd/ipam-alta-collector.service /etc/systemd/system/
sudo cp /var/www/ipam/systemd/ipam-alta-collector.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now ipam-alta-collector.timer
journalctl -u ipam-alta-collector.service -f
```
Environment overrides are in the service file (`DNS_RESOLVER`, `DNS_VERIFY_FORWARD`, etc.).

## Notes
- Do **not** call `app.run()` under Apache/mod_wsgi.
- Configure secrets in Apache with `SetEnv` or systemd environment.
- Route10 is the default DHCP server for LAN; ARP-based discovery on the LAN will see new clients and populate IPAM. DNS PTR lookup is optional.
