#!/usr/bin/env python3
import os, re, subprocess, sys, socket, logging
from ipaddress import ip_address
from datetime import datetime
try:
    import dns.resolver, dns.reversename, dns.exception
    HAS_DNSPYTHON = True
except Exception:
    HAS_DNSPYTHON = False
from app import app, db, Subnet, IPAddress
DNS_LOOKUP_ENABLED = os.environ.get("DNS_LOOKUP_ENABLED", "1") in ("1","true","yes","on")
DNS_TIMEOUT = float(os.environ.get("DNS_TIMEOUT", "1.5"))
DNS_VERIFY_FORWARD = os.environ.get("DNS_VERIFY_FORWARD", "0") in ("1","true","yes","on")
DNS_MAX_PER_RUN = int(os.environ.get("DNS_MAX_PER_RUN", "100"))
DNS_RESOLVER = [x.strip() for x in os.environ.get("DNS_RESOLVER", "").split(",") if x.strip()]
LOG_LEVEL = os.environ.get("COLLECTOR_LOG_LEVEL", "info").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO), format="%(levelname)s: %(message)s")
log = logging.getLogger("ipam-collector")
IPV4_RE = re.compile(r'(\d{1,3}(?:\.\d{1,3}){3})')
MAC_RE = re.compile(r'(([0-9a-f]{2}:){5}[0-9a-f]{2})', re.I)

def read_neighbors():
    for cmd in (["ip","-o","neigh","show"],["ip","-6","-o","neigh","show"]):
        try:
            out = subprocess.check_output(cmd, text=True, timeout=5)
            for ln in out.strip().splitlines():
                parts = ln.split()
                candidate = parts[0] if parts else None
                ip_str = None
                if candidate:
                    try:
                        ip_address(candidate); ip_str = candidate
                    except Exception:
                        m = IPV4_RE.search(ln); ip_str = m.group(1) if m else None
                macm = MAC_RE.search(ln)
                if ip_str and macm:
                    yield (ip_str, macm.group(1).lower())
        except Exception:
            pass
    try:
        out = subprocess.check_output(["arp","-an"], text=True, timeout=5)
        for ln in out.strip().splitlines():
            ipm = IPV4_RE.search(ln); macm = MAC_RE.search(ln)
            if ipm and macm:
                yield (ipm.group(1), macm.group(1).lower())
    except Exception:
        pass

_dns_queries = 0

def _init_resolver():
    if not HAS_DNSPYTHON:
        return None
    r = dns.resolver.Resolver(); r.lifetime = DNS_TIMEOUT; r.timeout = DNS_TIMEOUT
    if DNS_RESOLVER: r.nameservers = DNS_RESOLVER
    return r

_RESOLVER = _init_resolver()

def reverse_lookup(ip_str: str) -> str:
    global _dns_queries
    if not DNS_LOOKUP_ENABLED or _dns_queries >= DNS_MAX_PER_RUN:
        return ""
    if HAS_DNSPYTHON and _RESOLVER:
        try:
            _dns_queries += 1
            rev = dns.reversename.from_address(ip_str)
            answers = _RESOLVER.resolve(rev, "PTR")
            hostname = str(answers[0]).rstrip('.')
            if DNS_VERIFY_FORWARD:
                try:
                    _dns_queries += 1
                    rrtype = "A" if ":" not in ip_str else "AAAA"
                    forwards = _RESOLVER.resolve(hostname, rrtype)
                    ips = {str(r) for r in forwards}
                    if ip_str not in ips: return ""
                except Exception:
                    return ""
            return hostname
        except Exception as e:
            log.debug("PTR lookup failed for %s: %s", ip_str, e); return ""
    try:
        _dns_queries += 1; socket.setdefaulttimeout(DNS_TIMEOUT)
        h, _, _ = socket.gethostbyaddr(ip_str); return h or ""
    except Exception:
        return ""

def main():
    created = updated = scanned = 0
    with app.app_context():
        subnets = Subnet.query.all()
        for ip_str, mac in read_neighbors():
            scanned += 1
            try:
                ipobj = ip_address(ip_str)
            except Exception:
                continue
            matching = next((s for s in subnets if ipobj in s.network()), None)
            if not matching: continue
            net = matching.network()
            if net.version == 4 and net.prefixlen < 31 and ipobj in (net.network_address, net.broadcast_address):
                continue
            rec = IPAddress.query.filter_by(subnet_id=matching.id, ip=ip_str).first()
            hostname = reverse_lookup(ip_str)
            if rec is None:
                rec = IPAddress(ip=ip_str, hostname=hostname or "", assigned_to=mac, status="assigned", notes="Discovered via Alta Route10 collector", subnet_id=matching.id)
                db.session.add(rec); created += 1
            else:
                changed = False
                if hostname and not rec.hostname:
                    rec.hostname = hostname; changed = True
                if mac and (not rec.assigned_to):
                    rec.assigned_to = mac; changed = True
                if changed: updated += 1
        if created or updated: db.session.commit()
    log.info("[%s] scanned=%s created=%s updated=%s dns_queries=%s", datetime.utcnow().isoformat(timespec='seconds'), scanned, created, updated, _dns_queries)

if __name__ == "__main__":
    sys.exit(main())
