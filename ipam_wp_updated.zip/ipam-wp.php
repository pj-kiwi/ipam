<?php
/**
 * Plugin Name: IPAM for WordPress
 * Description: Simple IP Address Management (IPAM) with subnets, allocations, request workflow, admin UI, and a REST webhook to ingest DHCP events. Designed to integrate with an Alta Route10 collector.
 * Version: 1.0.0
 * Author: You
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: MIT
 */

if (!defined('ABSPATH')) { exit; }

if (!defined('IPAM_WP_VERSION')) define('IPAM_WP_VERSION', '1.0.0');
if (!defined('IPAM_WP_DIR')) define('IPAM_WP_DIR', plugin_dir_path(__FILE__));
if (!defined('IPAM_WP_URL')) define('IPAM_WP_URL', plugin_dir_url(__FILE__));

require_once IPAM_WP_DIR . 'includes/class-ipam-activator.php';
require_once IPAM_WP_DIR . 'includes/class-ipam-roles.php';
require_once IPAM_WP_DIR . 'includes/class-ipam-utils.php';
require_once IPAM_WP_DIR . 'includes/class-ipam-admin.php';
require_once IPAM_WP_DIR . 'includes/class-ipam-rest.php';
require_once IPAM_WP_DIR . 'public/shortcodes.php';

register_activation_hook(__FILE__, function(){
    IPAM_Activator::activate();
    IPAM_Roles::add_capabilities();
});

add_action('admin_menu', function(){ IPAM_Admin::register_menus(); });
add_action('rest_api_init', function(){ IPAM_REST::register_routes(); });
