#!/usr/bin/env python3
import os, re, subprocess, sys, socket, base64, json
from ipaddress import ip_address
try:
    import dns.resolver, dns.reversename
    HAS_DNS=True
except Exception:
    HAS_DNS=False
WP_BASE=os.environ.get('WP_BASE',''); WP_USER=os.environ.get('WP_USER',''); WP_APP_PASS=os.environ.get('WP_APP_PASS','')
DNS_ON=os.environ.get('DNS','1') in ('1','true','yes','on'); DNS_TIMEOUT=float(os.environ.get('DNS_TIMEOUT','1.0')); DNS_MAX=int(os.environ.get('DNS_MAX','100'))
DNS_RES=[x.strip() for x in os.environ.get('DNS_RESOLVER','').split(',') if x.strip()]
IP_RE=re.compile(r'(\d{1,3}(?:\.\d{1,3}){3})'); MAC_RE=re.compile(r'(([0-9a-f]{2}:){5}[0-9a-f]{2})', re.I)
if HAS_DNS:
    r=dns.resolver.Resolver(); r.lifetime=DNS_TIMEOUT; r.timeout=DNS_TIMEOUT
    if DNS_RES: r.nameservers=DNS_RES

def neighbors():
    for cmd in (["ip","-o","neigh","show"],["ip","-6","-o","neigh","show"]):
        try:
            out=subprocess.check_output(cmd,text=True,timeout=5)
            for ln in out.strip().splitlines():
                parts=ln.split(); cand=parts[0] if parts else None
                ip_str=None
                if cand:
                    try: ip_address(cand); ip_str=cand
                    except: m=IP_RE.search(ln); ip_str=m.group(1) if m else None
                macm=MAC_RE.search(ln)
                if ip_str and macm: yield (ip_str, macm.group(1).lower())
        except Exception: pass
    try:
        out=subprocess.check_output(["arp","-an"],text=True,timeout=5)
        for ln in out.strip().splitlines():
            ipm=IP_RE.search(ln); macm=MAC_RE.search(ln)
            if ipm and macm: yield (ipm.group(1), macm.group(1).lower())
    except Exception: pass

def ptr(ip):
    if not DNS_ON: return ''
    if not HAS_DNS:
        try: socket.setdefaulttimeout(DNS_TIMEOUT); h,_,_=socket.gethostbyaddr(ip); return h
        except Exception: return ''
    try: rev=dns.reversename.from_address(ip); ans=r.resolve(rev,'PTR'); return str(ans[0]).rstrip('.')
    except Exception: return ''

def post_events(events):
    import urllib.request
    url=WP_BASE.rstrip('/')+'/wp-json/ipam/v1/event'
    data=json.dumps({'events':events}).encode('utf-8')
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'})
    if WP_USER and WP_APP_PASS:
        token=base64.b64encode((WP_USER+':'+WP_APP_PASS).encode()).decode()
        req.add_header('Authorization','Basic '+token)
    with urllib.request.urlopen(req, timeout=10) as resp:
        print('POST', resp.status, resp.read().decode())

def main():
    if not WP_BASE: print('Set WP_BASE, WP_USER, WP_APP_PASS'); return 1
    evs=[]; q=0
    for ip,mac in neighbors():
        h='';
        if q<DNS_MAX: h=ptr(ip); q+=1
        evs.append({'ip':ip,'mac':mac,'hostname':h})
    if evs: post_events(evs)
    else: print('No neighbors found')
if __name__=='__main__': sys.exit(main())
