<?php
if (!defined('ABSPATH')) { exit; }
add_shortcode('ipam_request', function($atts){ if(!is_user_logged_in()) return '<p>You must be logged in to request an IP.</p>'; if(!current_user_can('request_ip')) return '<p>You do not have permission to request IPs.</p>'; $atts=shortcode_atts(['subnet_id'=>0],$atts); $sid=intval($atts['subnet_id']); if(!$sid) return '<p>Invalid subnet.</p>'; if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['ipam_request_nonce']) && wp_verify_nonce($_POST['ipam_request_nonce'],'ipam_request')){ $mode=sanitize_text_field($_POST['mode']??'next_free'); $ip=sanitize_text_field($_POST['ip']??''); $hn=sanitize_text_field($_POST['hostname']??''); $to=sanitize_text_field($_POST['assigned_to']??''); $notes=sanitize_textarea_field($_POST['notes']??''); global $wpdb; $R=$wpdb->prefix.'ipam_requests'; $wpdb->insert($R,['subnet_id'=>$sid,'user_id'=>get_current_user_id(),'mode'=>$mode,'ip'=>$ip?:None,'hostname'=>$hn,'assigned_to'=>$to,'notes'=>$notes,'status'=>'pending','created_at'=>current_time('mysql')]); return '<div class="notice notice-success"><p>Request submitted.</p></div>'; } ob_start(); ?>
<form method="post" class="ipam-request-form">
<?php wp_nonce_field('ipam_request','ipam_request_nonce'); ?>
<div><label>Mode</label><select name="mode" id="mode" onchange="document.getElementById('specificIp').style.display=(this.value==='specific')?'block':'none'"><option value="next_free">Next free IP</option><option value="specific">Specific IP</option></select></div>
<div id="specificIp" style="display:none"><label>IP Address</label><input name="ip" placeholder="192.168.1.10" /></div>
<div><label>Hostname</label><input name="hostname" /></div>
<div><label>Assigned To</label><input name="assigned_to" /></div>
<div><label>Notes</label><textarea name="notes"></textarea></div>
<button>Submit Request</button>
</form>
<?php return ob_get_clean(); });
