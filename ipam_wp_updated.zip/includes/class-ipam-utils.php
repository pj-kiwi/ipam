<?php
if (!defined('ABSPATH')) { exit; }
class IPAM_Utils {
    public static function ip_in_cidr($ip,$cidr){ if (strpos($cidr,':')!==false) return false; list($s,$m)=explode('/',$cidr); $il=ip2long($ip); if($il===false)return false; $sl=ip2long($s); $mask=-1 << (32-(int)$m); $low=$sl & $mask; $high=$low + (~$mask); return ($il>=$low && $il<=$high); }
}
