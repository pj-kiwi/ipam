<?php
if (!defined('ABSPATH')) { exit; }
class IPAM_Activator {
    public static function activate(){
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $cc = $wpdb->get_charset_collate();
        $S = $wpdb->prefix.'ipam_subnets';
        $I = $wpdb->prefix.'ipam_ips';
        $R = $wpdb->prefix.'ipam_requests';
        dbDelta("CREATE TABLE $S (id BIGINT UNSIGNED AUTO_INCREMENT, name VARCHAR(128), cidr VARCHAR(64) UNIQUE NOT NULL, description TEXT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id)) $cc;");
        dbDelta("CREATE TABLE $I (id BIGINT UNSIGNED AUTO_INCREMENT, subnet_id BIGINT UNSIGNED NOT NULL, ip VARCHAR(64) NOT NULL, hostname VARCHAR(255), status VARCHAR(32) NOT NULL DEFAULT 'assigned', assigned_to VARCHAR(255), notes TEXT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NULL, UNIQUE KEY subnet_ip(subnet_id,ip), PRIMARY KEY(id)) $cc;");
        dbDelta("CREATE TABLE $R (id BIGINT UNSIGNED AUTO_INCREMENT, subnet_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, mode VARCHAR(16) NOT NULL DEFAULT 'next_free', ip VARCHAR(64), hostname VARCHAR(255), assigned_to VARCHAR(255), notes TEXT, status VARCHAR(16) NOT NULL DEFAULT 'pending', admin_comment TEXT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NULL, PRIMARY KEY(id)) $cc;");
    }
}
