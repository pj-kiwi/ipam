<?php
if (!defined('ABSPATH')) { exit; }
class IPAM_Admin {
    public static function register_menus(){
        add_menu_page('IPAM','IPAM','manage_ipam','ipam-dashboard',[__CLASS__,'render_dashboard'],'dashicons-networking',58);
        add_submenu_page('ipam-dashboard','Subnets','Subnets','manage_ipam','ipam-subnets',[__CLASS__,'render_subnets']);
        add_submenu_page('ipam-dashboard','Requests','Requests','approve_ip_requests','ipam-requests',[__CLASS__,'render_requests']);
    }
    public static function render_dashboard(){ echo '<div class="wrap"><h1>IPAM Dashboard</h1><p>Use the Subnets menu to add networks and manage allocations. Use Requests to approve user IP requests.</p></div>'; }
    public static function render_subnets(){
        if(!current_user_can('manage_ipam')) wp_die('Unauthorized'); global $wpdb; $S=$wpdb->prefix.'ipam_subnets'; $I=$wpdb->prefix.'ipam_ips';
        if(isset($_POST['ipam_create_subnet']) && check_admin_referer('ipam_create_subnet')){ $name=sanitize_text_field($_POST['name']??''); $cidr=sanitize_text_field($_POST['cidr']??''); $desc=sanitize_textarea_field($_POST['description']??''); if($cidr){ $wpdb->insert($S,['name'=>$name,'cidr'=>$cidr,'description'=>$desc,'created_at'=>current_time('mysql')]); echo '<div class="updated"><p>Subnet created.</p></div>'; } }
        if(isset($_POST['ipam_delete_subnet']) && check_admin_referer('ipam_delete_subnet')){ $id=intval($_POST['id']); $wpdb->delete($I,['subnet_id'=>$id]); $wpdb->delete($S,['id'=>$id]); echo '<div class="updated"><p>Subnet deleted.</p></div>'; }
        $rows=$wpdb->get_results("SELECT s.*, (SELECT COUNT(*) FROM $I i WHERE i.subnet_id=s.id) used FROM $S s ORDER BY s.cidr ASC"); include IPAM_WP_DIR.'admin/views/subnets-list.php';
    }
    public static function render_requests(){
        if(!current_user_can('approve_ip_requests')) wp_die('Unauthorized'); global $wpdb; $R=$wpdb->prefix.'ipam_requests'; $I=$wpdb->prefix.'ipam_ips'; $S=$wpdb->prefix.'ipam_subnets';
        if(isset($_POST['ipam_approve']) && check_admin_referer('ipam_approve_request')){ $id=intval($_POST['id']); $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $R WHERE id=%d",$id)); if($r){ $ip=$r->ip; if($r->mode==='next_free' || !$ip){ $s=$wpdb->get_row($wpdb->prepare("SELECT * FROM $S WHERE id=%d",$r->subnet_id)); if($s){ $ip=self::next_free_ip($s->cidr,$r->subnet_id);} } if($ip){ $exists=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $I WHERE subnet_id=%d AND ip=%s",$r->subnet_id,$ip)); if(!$exists){ $wpdb->insert($I,['subnet_id'=>$r->subnet_id,'ip'=>$ip,'hostname'=>$r->hostname,'status'=>'assigned','assigned_to'=>$r->assigned_to,'notes'=>'Approved from request #'.$r->id,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')]); } $wpdb->update($R,['status'=>'approved','updated_at'=>current_time('mysql')],['id'=>$r->id]); } } }
        if(isset($_POST['ipam_reject']) && check_admin_referer('ipam_reject_request')){ $id=intval($_POST['id']); $comment=sanitize_text_field($_POST['admin_comment']??''); $wpdb->update($R,['status'=>'rejected','admin_comment'=>$comment,'updated_at'=>current_time('mysql')],['id'=>$id]); }
        $rows=$wpdb->get_results("SELECT r.*, s.cidr, u.user_login FROM $R r JOIN $S s ON s.id=r.subnet_id JOIN {$wpdb->users} u ON u.ID=r.user_id ORDER BY r.created_at DESC"); include IPAM_WP_DIR.'admin/views/requests-list.php';
    }
    private static function next_free_ip($cidr,$sid){ list($net,$m)=explode('/',$cidr); $base=ip2long($net); $m=(int)$m; $size=(1 << (32-$m)); global $wpdb; $I=$wpdb->prefix+'ipam_ips'; $used=$wpdb->get_col($wpdb->prepare("SELECT ip FROM ".$wpdb->prefix."ipam_ips WHERE subnet_id=%d",$sid)); $set=array_flip($used); for($i=1;$i<$size-1;$i++){ $cand=long2ip($base+$i); if(!isset($set[$cand]))return $cand; } return null; }
}
