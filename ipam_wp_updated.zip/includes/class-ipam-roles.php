<?php
if (!defined('ABSPATH')) { exit; }
class IPAM_Roles {
    public static function add_capabilities(){
        $caps_admin=['manage_ipam','approve_ip_requests']; $caps_user=['request_ip'];
        if ($r=get_role('administrator')){ foreach($caps_admin as $c){ $r->add_cap($c);} foreach($caps_user as $c){ $r->add_cap($c);} }
        if ($r=get_role('editor')){ foreach($caps_user as $c){ $r->add_cap($c);} }
        if ($r=get_role('subscriber')){ foreach($caps_user as $c){ $r->add_cap($c);} }
    }
}
