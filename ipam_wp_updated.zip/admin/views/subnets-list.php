<div class="wrap">
  <h1>Subnets</h1>
  <form method="post" class="card" style="max-width:600px;padding:1rem;margin:1rem 0;">
    <?php wp_nonce_field('ipam_create_subnet'); ?>
    <input type="hidden" name="ipam_create_subnet" value="1" />
    <div class="mb-3"><label>Name</label><input name="name" class="regular-text" /></div>
    <div class="mb-3"><label>CIDR *</label><input name="cidr" class="regular-text" placeholder="192.168.1.0/24" required /></div>
    <div class="mb-3"><label>Description</label><textarea name="description" class="large-text"></textarea></div>
    <button class="button button-primary">Create</button>
  </form>
  <table class="wp-list-table widefat fixed striped">
    <thead><tr><th>Name</th><th>CIDR</th><th>Used</th><th>Created</th><th></th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?php echo esc_html($r->name); ?></td>
        <td><?php echo esc_html($r->cidr); ?></td>
        <td><?php echo intval($r->used); ?></td>
        <td><?php echo esc_html($r->created_at); ?></td>
        <td>
          <form method="post" onsubmit="return confirm('Delete subnet and all allocations?');" style="display:inline-block;">
            <?php wp_nonce_field('ipam_delete_subnet'); ?>
            <input type="hidden" name="ipam_delete_subnet" value="1" />
            <input type="hidden" name="id" value="<?php echo intval($r->id); ?>" />
            <button class="button button-link-delete">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
