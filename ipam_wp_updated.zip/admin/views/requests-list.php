<div class="wrap">
  <h1>IP Requests</h1>
  <table class="wp-list-table widefat fixed striped">
    <thead><tr><th>#</th><th>Subnet</th><th>Mode</th><th>IP</th><th>Hostname</th><th>Assigned To</th><th>User</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?php echo intval($r->id); ?></td>
          <td><?php echo esc_html($r->cidr); ?></td>
          <td><?php echo esc_html($r->mode); ?></td>
          <td><?php echo esc_html($r->ip ?: '-'); ?></td>
          <td><?php echo esc_html($r->hostname); ?></td>
          <td><?php echo esc_html($r->assigned_to); ?></td>
          <td><?php echo esc_html($r->user_login); ?></td>
          <td><?php echo esc_html($r->status); ?></td>
          <td>
            <?php if ($r->status==='pending'): ?>
              <form method="post" style="display:inline-block;">
                <?php wp_nonce_field('ipam_approve_request'); ?>
                <input type="hidden" name="id" value="<?php echo intval($r->id); ?>" />
                <button class="button button-primary" name="ipam_approve" value="1">Approve</button>
              </form>
              <form method="post" style="display:inline-block;" onsubmit="return confirm('Reject request?');">
                <?php wp_nonce_field('ipam_reject_request'); ?>
                <input type="hidden" name="id" value="<?php echo intval($r->id); ?>" />
                <input type="hidden" name="admin_comment" value="" />
                <button class="button">Reject</button>
              </form>
            <?php else: ?>
              <em>—</em>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
