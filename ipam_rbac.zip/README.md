# IPAM (Flask) with RBAC and Request Workflow

A minimal IP Address Management app with web UI, Basic Auth, admin/user roles, and an approve/reject request workflow.

## Features
- Admins: create/delete subnets, assign/release IPs, approve/reject requests
- Users: view subnets/allocations, submit IP requests (next-free or specific)
- SQLite by default, switchable via `DATABASE_URL`

## Quickstart (Local)
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export IPAM_ADMIN_USER=admin IPAM_ADMIN_PASS='ChangeMeNow!' SECRET_KEY='a-long-random-secret'
python app.py
```
Open http://127.0.0.1:5000 and authenticate with your credentials.

## Production (Gunicorn)
```bash
pip install -r requirements.txt
export SECRET_KEY='set-a-strong-secret'
export IPAM_ADMIN_USER=admin IPAM_ADMIN_PASS='ChangeMeNow!'
# Optional DB: export DATABASE_URL='postgresql+psycopg://user:pass@host/dbname'
gunicorn -b 0.0.0.0:8000 app:app
```

## Docker
```bash
docker build -t ipam-rbac .
docker run -p 8000:8000 -e SECRET_KEY='set-secret' -e IPAM_ADMIN_USER=admin -e IPAM_ADMIN_PASS='ChangeMeNow!' ipam-rbac
```
Or with Compose:
```bash
docker compose up --build
```

## Create Users
```bash
flask --app app.py create-user
```

## Security Notes
- Basic Auth must be served over **HTTPS**. Put a reverse proxy (Nginx/Traefik) with TLS in front.
- Change default admin credentials immediately.
- Consider migrating to session-based login + CSRF for public exposure.

## License
MIT
