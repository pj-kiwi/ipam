import os
from functools import wraps
from datetime import datetime
from ipaddress import ip_network, ip_address
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

# -------------------------
# Config
# -------------------------
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///ipam.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-in-production")

db = SQLAlchemy(app)
auth = HTTPBasicAuth()

# -------------------------
# Models
# -------------------------
class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)  # role flag

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Subnet(db.Model):
    __tablename__ = "subnets"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    cidr = db.Column(db.String(64), unique=True, nullable=False)
    description = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    ip_addresses = db.relationship("IPAddress", backref="subnet", cascade="all, delete-orphan")

    def network(self):
        return ip_network(self.cidr, strict=False)

    def total_hosts(self):
        net = self.network()
        return sum(1 for _ in net.hosts())

    def used_count(self):
        return IPAddress.query.filter_by(subnet_id=self.id).count()

    def free_count(self):
        return self.total_hosts() - self.used_count()


class IPAddress(db.Model):
    __tablename__ = "ip_addresses"
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(64), nullable=False)
    hostname = db.Column(db.String(255), default="")
    status = db.Column(db.String(32), default="assigned")  # assigned | reserved
    assigned_to = db.Column(db.String(255), default="")
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    subnet_id = db.Column(db.Integer, db.ForeignKey("subnets.id"), nullable=False)

    __table_args__ = (
        db.UniqueConstraint("subnet_id", "ip", name="uq_subnet_ip"),
    )


# NEW: Requests model (users request IPs; admins approve/reject)
class IPRequest(db.Model):
    __tablename__ = "ip_requests"
    id = db.Column(db.Integer, primary_key=True)
    subnet_id = db.Column(db.Integer, db.ForeignKey("subnets.id"), nullable=False)
    ip = db.Column(db.String(64), nullable=True)  # optional if mode=next_free
    mode = db.Column(db.String(16), default="next_free")  # next_free | specific
    hostname = db.Column(db.String(255), default="")
    assigned_to = db.Column(db.String(255), default="")
    notes = db.Column(db.Text, default="")

    status = db.Column(db.String(16), default="pending")  # pending | approved | rejected
    admin_comment = db.Column(db.Text, default="")
    requested_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    requested_by = db.relationship("User")
    subnet = db.relationship("Subnet")


# -------------------------
# Auth & Role helpers
# -------------------------
@auth.verify_password
def verify_password(username, password):
    user = User.query.filter_by(username=username).first()
    if user and user.check_password(password):
        return user
    return None

def admin_required(f):
    @wraps(f)
    @auth.login_required
    def wrapped(*args, **kwargs):
        user = auth.current_user()
        if not user or not user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return wrapped

@app.errorhandler(403)
def forbidden(e):
    flash("You do not have permission to perform that action.", "warning")
    return redirect(url_for("dashboard"))

@app.before_first_request
def init_db():
    db.create_all()
    if User.query.count() == 0:
        default_user = os.environ.get("IPAM_ADMIN_USER", "admin")
        default_pass = os.environ.get("IPAM_ADMIN_PASS", "admin")
        u = User(username=default_user, is_admin=True)
        u.set_password(default_pass)
        db.session.add(u)
        db.session.commit()
        app.logger.warning(
            f"Created default admin user '{default_user}'. Change the password immediately."
        )

@app.context_processor
def inject_current_user():
    return {"current_user": auth.current_user()}

# -------------------------
# Helpers
# -------------------------

def find_next_free_ip(subnet: Subnet):
    net = subnet.network()
    used_ips = set(ip_address(rec.ip) for rec in IPAddress.query.filter_by(subnet_id=subnet.id).all())
    for host in net.hosts():
        if host not in used_ips:
            return host
    return None


def validate_ip_in_subnet(ip_str: str, subnet: Subnet):
    try:
        ip_obj = ip_address(ip_str)
    except ValueError:
        return False, "Invalid IP format"
    if ip_obj not in subnet.network():
        return False, f"{ip_str} is not inside {subnet.cidr}"
    net = subnet.network()
    if net.version == 4 and net.prefixlen < 31:
        if ip_obj == net.network_address or ip_obj == net.broadcast_address:
            return False, f"{ip_str} is network/broadcast address for {subnet.cidr}"
    return True, ""

# -------------------------
# Routes: Dashboard / Lists
# -------------------------
@app.route("/")
@auth.login_required
def dashboard():
    subnets = Subnet.query.order_by(Subnet.created_at.desc()).all()
    totals = {
        "subnets": len(subnets),
        "total_hosts": sum(s.total_hosts() for s in subnets) if subnets else 0,
        "used": sum(s.used_count() for s in subnets) if subnets else 0,
        "free": sum(s.free_count() for s in subnets) if subnets else 0,
    }
    user = auth.current_user()
    if user.is_admin:
        req_counts = {
            "pending": IPRequest.query.filter_by(status="pending").count(),
            "approved": IPRequest.query.filter_by(status="approved").count(),
            "rejected": IPRequest.query.filter_by(status="rejected").count(),
        }
    else:
        req_counts = {
            "pending": IPRequest.query.filter_by(status="pending", requested_by_id=user.id).count(),
            "approved": IPRequest.query.filter_by(status="approved", requested_by_id=user.id).count(),
            "rejected": IPRequest.query.filter_by(status="rejected", requested_by_id=user.id).count(),
        }
    return render_template("dashboard.html", subnets=subnets, totals=totals, req_counts=req_counts)


@app.route("/subnets")
@auth.login_required
def list_subnets():
    subnets = Subnet.query.order_by(Subnet.cidr.asc()).all()
    return render_template("subnets.html", subnets=subnets)

# -------------------------
# Routes: Subnet Admin (admins only)
# -------------------------
@app.route("/subnets/new", methods=["GET", "POST"])
@admin_required
def new_subnet():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        cidr = request.form.get("cidr", "").strip()
        description = request.form.get("description", "").strip()
        try:
            net = ip_network(cidr, strict=False)
        except Exception as e:
            flash(f"Invalid network: {e}", "danger")
            return render_template("subnet_form.html", subnet=None)

        if Subnet.query.filter_by(cidr=str(net)).first():
            flash("This subnet already exists.", "warning")
            return render_template("subnet_form.html", subnet=None)

        s = Subnet(name=name or str(net), cidr=str(net), description=description)
        db.session.add(s)
        db.session.commit()
        flash("Subnet created.", "success")
        return redirect(url_for("list_subnets"))
    return render_template("subnet_form.html", subnet=None)


@app.route("/subnets/<int:subnet_id>/delete", methods=["POST"])
@admin_required
def delete_subnet(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    db.session.delete(subnet)
    db.session.commit()
    flash("Subnet deleted.", "info")
    return redirect(url_for("list_subnets"))

# -------------------------
# Routes: Subnet details (everyone)
# -------------------------
@app.route("/subnets/<int:subnet_id>")
@auth.login_required
def subnet_detail(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    allocations = IPAddress.query.filter_by(subnet_id=subnet.id).order_by(IPAddress.ip.asc()).all()
    reserved = sum(1 for a in allocations if a.status == "reserved")
    assigned = sum(1 for a in allocations if a.status == "assigned")
    return render_template(
        "subnet_detail.html",
        subnet=subnet,
        allocations=allocations,
        reserved=reserved,
        assigned=assigned
    )

# -------------------------
# Routes: IP allocation (admins only)
# -------------------------
@app.route("/subnets/<int:subnet_id>/assign", methods=["GET", "POST"])
@admin_required
def assign_ip(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    if request.method == "POST":
        mode = request.form.get("mode", "next_free")
        hostname = request.form.get("hostname", "").strip()
        assigned_to = request.form.get("assigned_to", "").strip()
        status = request.form.get("status", "assigned")
        notes = request.form.get("notes", "").strip()

        chosen_ip = None
        if mode == "next_free":
            chosen_ip = find_next_free_ip(subnet)
            if not chosen_ip:
                flash("No free IPs left in this subnet.", "warning")
                return render_template("ip_assign_form.html", subnet=subnet)
        else:
            ip_str = request.form.get("ip", "").strip()
            ok, msg = validate_ip_in_subnet(ip_str, subnet)
            if not ok:
                flash(msg, "danger")
                return render_template("ip_assign_form.html", subnet=subnet)
            chosen_ip = ip_address(ip_str)
            if IPAddress.query.filter_by(subnet_id=subnet.id, ip=str(chosen_ip)).first():
                flash("That IP is already allocated.", "danger")
                return render_template("ip_assign_form.html", subnet=subnet)

        rec = IPAddress(
            ip=str(chosen_ip),
            hostname=hostname,
            assigned_to=assigned_to,
            status=status,
            notes=notes,
            subnet_id=subnet.id
        )
        db.session.add(rec)
        db.session.commit()
        flash(f"Allocated {chosen_ip}", "success")
        return redirect(url_for("subnet_detail", subnet_id=subnet.id))
    return render_template("ip_assign_form.html", subnet=subnet)


@app.route("/ips/<int:ip_id>/release", methods=["POST"])
@admin_required
def release_ip(ip_id):
    rec = IPAddress.query.get_or_404(ip_id)
    subnet_id = rec.subnet_id
    db.session.delete(rec)
    db.session.commit()
    flash("IP released.", "info")
    return redirect(url_for("subnet_detail", subnet_id=subnet_id))

# -------------------------
# Routes: Request workflow
# -------------------------
@app.route("/requests")
@auth.login_required
def list_requests():
    user = auth.current_user()
    status_filter = request.args.get("status")
    q = IPRequest.query
    if not user.is_admin:
        q = q.filter_by(requested_by_id=user.id)
    if status_filter:
        q = q.filter_by(status=status_filter)
    reqs = q.order_by(IPRequest.created_at.desc()).all()
    return render_template("requests.html", reqs=reqs)


@app.route("/requests/new/<int:subnet_id>", methods=["GET", "POST"])
@auth.login_required
def request_ip(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    user = auth.current_user()

    if request.method == "POST":
        mode = request.form.get("mode", "next_free")
        hostname = request.form.get("hostname", "").strip()
        assigned_to = request.form.get("assigned_to", "").strip()
        notes = request.form.get("notes", "").strip()

        ip_str = None
        if mode == "specific":
            ip_str = request.form.get("ip", "").strip()
            ok, msg = validate_ip_in_subnet(ip_str, subnet)
            if not ok:
                flash(msg, "danger")
                return render_template("request_form.html", subnet=subnet)

        req = IPRequest(
            subnet_id=subnet.id,
            ip=ip_str,
            mode=mode,
            hostname=hostname,
            assigned_to=assigned_to,
            notes=notes,
            requested_by_id=user.id,
            status="pending",
        )
        db.session.add(req)
        db.session.commit()
        flash("Request submitted.", "success")
        return redirect(url_for("list_requests"))

    return render_template("request_form.html", subnet=subnet)


@app.route("/requests/<int:req_id>/approve", methods=["POST"])
@admin_required
def approve_request(req_id):
    req = IPRequest.query.get_or_404(req_id)
    if req.status != "pending":
        flash("Request is not pending.", "warning")
        return redirect(url_for("list_requests"))

    subnet = Subnet.query.get_or_404(req.subnet_id)

    chosen_ip = None
    if req.mode == "next_free":
        chosen_ip = find_next_free_ip(subnet)
        if not chosen_ip:
            flash("No free IPs left in this subnet. Cannot approve.", "danger")
            return redirect(url_for("list_requests"))
    else:
        ok, msg = validate_ip_in_subnet(req.ip, subnet)
        if not ok:
            flash(f"Invalid specific IP in request: {msg}", "danger")
            return redirect(url_for("list_requests"))
        if IPAddress.query.filter_by(subnet_id=subnet.id, ip=req.ip).first():
            flash("Requested IP is already allocated. Consider rejecting.", "danger")
            return redirect(url_for("list_requests"))
        chosen_ip = ip_address(req.ip)

    rec = IPAddress(
        ip=str(chosen_ip),
        hostname=req.hostname,
        assigned_to=req.assigned_to,
        status="assigned",
        notes=f"Approved from request #{req.id}. {req.notes or ''}".strip(),
        subnet_id=subnet.id
    )
    db.session.add(rec)
    req.status = "approved"
    db.session.commit()
    flash(f"Request #{req.id} approved. Allocated {chosen_ip}.", "success")
    return redirect(url_for("list_requests"))


@app.route("/requests/<int:req_id>/reject", methods=["POST"])
@admin_required
def reject_request(req_id):
    req = IPRequest.query.get_or_404(req_id)
    if req.status != "pending":
        flash("Request is not pending.", "warning")
        return redirect(url_for("list_requests"))
    comment = request.form.get("admin_comment", "").strip()
    req.status = "rejected"
    req.admin_comment = comment
    db.session.commit()
    flash("Request rejected.", "info")
    return redirect(url_for("list_requests"))

# -------------------------
# CLI utilities (optional)
# -------------------------
@app.cli.command("create-user")
def create_user():
    """Create a user interactively: flask create-user"""
    username = input("Username: ").strip()
    password = input("Password: ").strip()
    is_admin_str = input("Is admin? (y/N): ").strip().lower()
    is_admin = is_admin_str in ("y", "yes", "true", "1")
    if not username or not password:
        print("Username and Password are required")
        return
    if User.query.filter_by(username=username).first():
        print("User already exists")
        return
    u = User(username=username, is_admin=is_admin)
    u.set_password(password)
    db.session.add(u)
    db.session.commit()
    print(f"User '{username}' created. Admin={is_admin}")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
